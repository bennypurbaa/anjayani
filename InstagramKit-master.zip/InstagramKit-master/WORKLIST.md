InstagramUserHighlight 
InstagramUserIGTV
Target new users based on accounts, hashtags and location
Support Proxy
Hashtag Followers List